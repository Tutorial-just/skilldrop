import Link from "next/link";
import { redirect } from "next/navigation";
import {
  ArrowLeft,
  Bookmark,
  CalendarClock,
  CheckCircle2,
  Compass,
  Euro,
  Eye,
  Globe2,
  HeartHandshake,
  Languages,
  Lightbulb,
  Lock,
  Mail,
  Save,
  Search,
  ShieldCheck,
  Sparkles,
  UserRound,
  WalletCards,
} from "lucide-react";
import Image from "next/image";
import {
  updateBuyerAccountAction,
  updateBuyerPreferencesAction,
} from "@/server/actions/buyer-settings.actions";
import { requireRole } from "@/lib/auth/get-current-user";
import { prisma } from "@/lib/prisma";
import { Badge } from "@/components/ui/badge";
import { ButtonLink } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

type BuyerProfilePageProps = {
  searchParams?: Promise<{
    saved?: string;
    error?: string;
  }>;
};

const profileIdeas = [
  {
    title: "Languages",
    text: "Choose the languages you prefer for calls and recommendations.",
    icon: Languages,
  },
  {
    title: "Topics",
    text: "Add interests like career, documents, moving abroad or business.",
    icon: HeartHandshake,
  },
  {
    title: "Budget",
    text: "Set a comfortable price range to improve helper suggestions.",
    icon: Euro,
  },
  {
    title: "Timezone",
    text: "Help SkillDrop show times that match your real schedule.",
    icon: Globe2,
  },
];

const languageSuggestions = [
  "English",
  "French",
  "Spanish",
  "German",
  "Italian",
  "Russian",
  "Arabic",
  "Portuguese",
  "Turkish",
  "Ukrainian",
];

const topicSuggestions = [
  "career",
  "CV review",
  "documents",
  "translation",
  "moving abroad",
  "life advice",
  "business",
  "study",
  "language practice",
  "admin help",
];

export default async function BuyerProfilePage({
  searchParams,
}: BuyerProfilePageProps) {
  const { user } = await requireRole(["buyer", "admin"]);
  const resolvedSearchParams = searchParams ? await searchParams : {};

  const email = user.email?.toLowerCase();

  if (!email) {
    redirect("/sign-in");
  }

  const buyer = await prisma.user.findUnique({
    where: {
      email,
    },
    include: {
      buyerSettings: true,
      bookings: {
        orderBy: {
          startTime: "desc",
        },
        take: 30,
      },
      savedExperts: {
        take: 10,
      },
      reviews: {
        take: 10,
      },
    },
  });

  if (!buyer) {
    redirect("/sign-in");
  }

  const settings = buyer.buyerSettings;
  const now = new Date();

  const upcomingBookings = buyer.bookings.filter(
    (booking) =>
      booking.startTime >= now &&
      (booking.status === "PAID" || booking.status === "CONFIRMED"),
  );

  const completedBookings = buyer.bookings.filter(
    (booking) => booking.status === "COMPLETED",
  );

  const pendingBookings = buyer.bookings.filter(
    (booking) => booking.status === "PENDING" && booking.startTime >= now,
  );

  const reviewedCalls = buyer.reviews.length;

  const preferredLanguages = settings?.preferredLanguages ?? [];
  const interests = settings?.interests ?? [];

  const budgetMin = settings?.budgetMinCents
    ? String(settings.budgetMinCents / 100)
    : "";

  const budgetMax = settings?.budgetMaxCents
    ? String(settings.budgetMaxCents / 100)
    : "";

  const displayName = buyer.name?.trim() || "Friend";

  return (
    <main>
      <section className="relative overflow-hidden border-b border-[var(--border)]">
        <div className="surface-grid absolute inset-0 opacity-40" />
        <div className="absolute left-[-180px] top-[-220px] h-[420px] w-[420px] rounded-full bg-[var(--primary)]/10 blur-3xl" />
        <div className="absolute right-[-180px] top-[120px] h-[420px] w-[420px] rounded-full bg-[var(--accent)]/10 blur-3xl" />

        <div className="relative p-6 md:p-8 lg:p-10">
          <Link
            href="/buyer"
            className="inline-flex items-center gap-2 text-sm font-bold text-[var(--primary-dark)]"
          >
            <ArrowLeft size={16} />
            Back to dashboard
          </Link>

          {resolvedSearchParams.saved ? (
            <div className="mt-6 rounded-2xl border border-[var(--success)]/20 bg-[var(--success-soft)] p-4 text-sm font-bold text-[var(--success)]">
              {resolvedSearchParams.saved === "account"
                ? "Profile name saved."
                : "Profile preferences saved."}
            </div>
          ) : null}

          {resolvedSearchParams.error ? (
            <div className="mt-6 rounded-2xl border border-[var(--danger)]/20 bg-[var(--danger-soft)] p-4 text-sm font-bold text-[var(--danger)]">
              {formatProfileError(resolvedSearchParams.error)}
            </div>
          ) : null}

          <div className="mt-6 grid gap-8 xl:grid-cols-[1fr_auto] xl:items-end">
            <div>
              <Badge variant="primary">
                <UserRound size={14} />
                Buyer profile
              </Badge>

              <h1 className="heading-lg mt-5 max-w-4xl text-balance">
                Make SkillDrop fit your needs.
              </h1>

              <p className="mt-4 max-w-2xl text-lg leading-8 text-[var(--muted-foreground)]">
                Your profile helps personalize search, recommendations,
                reminders, languages, topics and booking suggestions.
              </p>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row xl:flex-col">
              <ButtonLink href="/experts">
                <Search size={18} />
                Find helpers
              </ButtonLink>

              <ButtonLink href="/buyer/saved" variant="secondary">
                <Bookmark size={18} />
                Saved helpers
              </ButtonLink>
            </div>
          </div>

          <div className="mt-8 grid gap-3 md:grid-cols-2 xl:grid-cols-4">

            <MetricCard
              label="Saved helpers"
              value={String(buyer.savedExperts.length)}
              hint="Profiles saved"
            />

            <MetricCard
              label="Upcoming"
              value={String(upcomingBookings.length)}
              hint="Scheduled calls"
            />

            <MetricCard
              label="Pending"
              value={String(pendingBookings.length)}
              hint="Waiting payment"
            />

            <MetricCard
              label="Reviews"
              value={String(reviewedCalls)}
              hint="Feedback written"
            />
          </div>
        </div>
      </section>

      <section className="p-6 md:p-8 lg:p-10">
        <div className="grid gap-6">
          <div className="grid gap-6">
           

            <Card className="p-5 md:p-6">
              <Badge variant="accent">
                <Eye size={14} />
                Private buyer profile
              </Badge>

              <div className="mt-5 flex items-start gap-4 rounded-[26px] border border-[var(--border)] bg-[var(--card-soft)] p-5">
                <div className="relative flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-[24px] bg-gradient-to-br from-[var(--primary)] to-[#8b5cf6] text-2xl font-black text-white shadow-sm">
                   {buyer.avatarUrl ? (
                     <Image
                       src={buyer.avatarUrl}
                       alt={displayName}
                       fill
                       sizes="64px"
                       className="object-cover"
                       unoptimized
                      />
                     ) : (
                      displayName.charAt(0).toUpperCase()
                   )}
                </div>

                <div className="min-w-0">
                  <h2 className="text-2xl font-black tracking-[-0.04em] text-[var(--foreground)]">
                    {displayName}
                  </h2>

                  <p className="mt-1 break-all text-sm font-medium leading-6 text-[var(--muted-foreground)]">
                    {buyer.email}
                  </p>

                  <div className="mt-3 flex flex-wrap gap-2">
                    <Badge>
                      <Lock size={14} />
                      Private
                    </Badge>

                    <Badge variant="primary">
                      <Compass size={14} />
                      Personalized
                    </Badge>

                    {settings?.allowReminders ?? true ? (
                      <Badge variant="success">
                        <BellIcon />
                        Reminders on
                      </Badge>
                    ) : (
                      <Badge variant="accent">Reminders off</Badge>
                    )}
                  </div>
                </div>
              </div>

              <p className="mt-5 leading-7 text-[var(--muted-foreground)]">
                This profile is not a public helper profile. It is used to make
                your buyer workspace more useful: better search, saved helpers,
                suggested topics, reminders and booking defaults.
              </p>

              <div className="mt-6 grid gap-3 md:grid-cols-2">
                {profileIdeas.map((item) => {
                  const Icon = item.icon;

                  return (
                    <div
                      key={item.title}
                      className="rounded-[22px] border border-[var(--border)] bg-[var(--card-soft)] p-4"
                    >
                      <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[var(--primary-soft)] text-[var(--primary-dark)]">
                        <Icon size={18} />
                      </div>

                      <h3 className="mt-4 font-bold tracking-[-0.02em] text-[var(--foreground)]">
                        {item.title}
                      </h3>

                      <p className="mt-2 text-sm font-medium leading-6 text-[var(--muted-foreground)]">
                        {item.text}
                      </p>
                    </div>
                  );
                })}
              </div>
            </Card>
          </div>

          <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
            <Card className="p-5 md:p-6">
              <Badge variant="primary">
                <UserRound size={14} />
                Basic profile
              </Badge>

              <h2 className="mt-4 text-3xl font-black tracking-[-0.05em] text-[var(--foreground)]">
                Your identity
              </h2>

              <p className="mt-3 text-sm leading-6 text-[var(--muted-foreground)]">
                This name appears in your buyer workspace, bookings and reviews.
              </p>

              <form action={updateBuyerAccountAction} className="mt-6 grid gap-5">
                <div>
                  <label
                    htmlFor="name"
                    className="text-sm font-bold text-[var(--foreground)]"
                  >
                    Display name
                  </label>

                  <input
                    id="name"
                    name="name"
                    type="text"
                    maxLength={80}
                    defaultValue={buyer.name ?? ""}
                    className="input mt-2"
                    placeholder="Your name"
                  />

                  <p className="mt-2 text-xs font-medium text-[var(--muted-foreground)]">
                    Use a name helpers can recognize when preparing your call.
                  </p>
                </div>

                <div className="rounded-2xl border border-[var(--border)] bg-[var(--card-soft)] p-4">
                  <div className="flex items-center gap-3">
                    <Mail
                      size={17}
                      className="text-[var(--muted-foreground)]"
                    />

                    <div className="min-w-0">
                      <p className="text-xs font-bold uppercase tracking-[0.12em] text-[var(--muted-foreground)]">
                        Email
                      </p>

                      <p className="mt-1 truncate font-bold text-[var(--foreground)]">
                        {buyer.email}
                      </p>
                    </div>
                  </div>
                </div>

                <button type="submit" className="btn btn-primary">
                  <Save size={18} />
                  Save name
                </button>
              </form>
            </Card>

            <Card className="p-5 md:p-6">
              <Badge variant="primary">
                <WalletCards size={14} />
                Preferences
              </Badge>

              <h2 className="mt-4 text-3xl font-black tracking-[-0.05em] text-[var(--foreground)]">
                What kind of help do you need?
              </h2>

              <p className="mt-3 max-w-2xl leading-7 text-[var(--muted-foreground)]">
                These preferences can power search, recommendations, reminders
                and booking defaults.
              </p>

              <form action={updateBuyerPreferencesAction} className="mt-7 grid gap-6">
                <div className="grid gap-5 xl:grid-cols-2">
                  <div>
                    <label
                      htmlFor="preferredTimezone"
                      className="text-sm font-bold text-[var(--foreground)]"
                    >
                      Preferred timezone
                    </label>

                    <input
                      id="preferredTimezone"
                      name="preferredTimezone"
                      type="text"
                      maxLength={80}
                      defaultValue={settings?.preferredTimezone ?? ""}
                      className="input mt-2"
                      placeholder="Europe/Paris"
                    />

                    <p className="mt-2 text-xs font-medium text-[var(--muted-foreground)]">
                      Example: Europe/Paris, Europe/London, America/New_York.
                    </p>
                  </div>

                  <div>
                    <label
                      htmlFor="defaultReminderMin"
                      className="text-sm font-bold text-[var(--foreground)]"
                    >
                      Default call reminder
                    </label>

                    <select
                      id="defaultReminderMin"
                      name="defaultReminderMin"
                      defaultValue={String(settings?.defaultReminderMin ?? 30)}
                      className="input mt-2"
                    >
                      <option value="10">10 minutes before</option>
                      <option value="15">15 minutes before</option>
                      <option value="30">30 minutes before</option>
                      <option value="60">1 hour before</option>
                      <option value="120">2 hours before</option>
                      <option value="1440">1 day before</option>
                    </select>
                  </div>

                  <div>
                    <label
                      htmlFor="preferredLanguages"
                      className="text-sm font-bold text-[var(--foreground)]"
                    >
                      Preferred languages
                    </label>

                    <input
                      id="preferredLanguages"
                      name="preferredLanguages"
                      type="text"
                      maxLength={300}
                      defaultValue={preferredLanguages.join(", ")}
                      className="input mt-2"
                      placeholder="English, French, Russian"
                    />

                    <p className="mt-2 text-xs font-medium text-[var(--muted-foreground)]">
                      Separate languages with commas.
                    </p>

                    <SuggestionRow items={languageSuggestions} />
                  </div>

                  <div>
                    <label
                      htmlFor="interests"
                      className="text-sm font-bold text-[var(--foreground)]"
                    >
                      Interests / topics
                    </label>

                    <input
                      id="interests"
                      name="interests"
                      type="text"
                      maxLength={500}
                      defaultValue={interests.join(", ")}
                      className="input mt-2"
                      placeholder="career, documents, moving abroad, life advice"
                    />

                    <p className="mt-2 text-xs font-medium text-[var(--muted-foreground)]">
                      Separate topics with commas.
                    </p>

                    <SuggestionRow items={topicSuggestions} />
                  </div>

                  <div>
                    <label
                      htmlFor="budgetMin"
                      className="text-sm font-bold text-[var(--foreground)]"
                    >
                      Minimum budget
                    </label>

                    <div className="relative mt-2">
                      <Euro
                        size={17}
                        className="pointer-events-none absolute left-5 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]"
                      />

                      <input
                        id="budgetMin"
                        name="budgetMin"
                        type="number"
                        min="0"
                        step="1"
                        defaultValue={budgetMin}
                        className="input pl-12"
                        placeholder="10"
                      />
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="budgetMax"
                      className="text-sm font-bold text-[var(--foreground)]"
                    >
                      Maximum budget
                    </label>

                    <div className="relative mt-2">
                      <Euro
                        size={17}
                        className="pointer-events-none absolute left-5 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]"
                      />

                      <input
                        id="budgetMax"
                        name="budgetMax"
                        type="number"
                        min="0"
                        step="1"
                        defaultValue={budgetMax}
                        className="input pl-12"
                        placeholder="100"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <ToggleCard
                    name="hideEmail"
                    title="Hide my email from helpers"
                    text="Helpers should contact you through SkillDrop, not directly by email."
                    defaultChecked={settings?.hideEmail ?? true}
                  />

                  <ToggleCard
                    name="allowReminders"
                    title="Allow call reminders"
                    text="Receive reminders and booking updates from the platform."
                    defaultChecked={settings?.allowReminders ?? true}
                  />
                </div>

                <div className="rounded-[24px] border border-[var(--border)] bg-[var(--primary-soft)] p-5">
                  <div className="flex gap-3">
                    <ShieldCheck
                      size={20}
                      className="mt-0.5 shrink-0 text-[var(--primary-dark)]"
                    />

                    <div>
                      <p className="font-bold text-[var(--primary-dark)]">
                        Preferences are private
                      </p>

                      <p className="mt-1 text-sm font-medium leading-6 text-[var(--primary-dark)]/80">
                        Helpers do not see this full profile. It is mainly used
                        for your own workspace and future recommendations.
                      </p>
                    </div>
                  </div>
                </div>

                <button type="submit" className="btn btn-primary w-full md:w-fit">
                  <Save size={18} />
                  Save profile preferences
                </button>
              </form>
            </Card>
          </div>

          <div className="grid gap-6 xl:grid-cols-[1fr_0.85fr]">
            <Card className="p-5 md:p-6">
              <Badge variant="accent">
                <Lightbulb size={14} />
                Smart next step
              </Badge>

              <div className="mt-5 grid gap-5 lg:grid-cols-[auto_1fr_auto] lg:items-center">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[var(--accent-soft)] text-[var(--accent)]">
                  <Compass size={24} />
                </div>

                <div>
                  <h2 className="text-2xl font-black tracking-[-0.04em] text-[var(--foreground)]">
                    {getNextActionTitle({
                      hasLanguages: preferredLanguages.length > 0,
                      hasInterests: interests.length > 0,
                      hasSavedHelpers: buyer.savedExperts.length > 0,
                      hasUpcoming: upcomingBookings.length > 0,
                      hasPendingPayment: pendingBookings.length > 0,
                    })}
                  </h2>

                  <p className="mt-2 leading-7 text-[var(--muted-foreground)]">
                    {getNextActionText({
                      hasLanguages: preferredLanguages.length > 0,
                      hasInterests: interests.length > 0,
                      hasSavedHelpers: buyer.savedExperts.length > 0,
                      hasUpcoming: upcomingBookings.length > 0,
                      hasPendingPayment: pendingBookings.length > 0,
                    })}
                  </p>
                </div>

                <ButtonLink
                  href={getNextActionHref({
                    hasLanguages: preferredLanguages.length > 0,
                    hasInterests: interests.length > 0,
                    hasSavedHelpers: buyer.savedExperts.length > 0,
                    hasUpcoming: upcomingBookings.length > 0,
                    hasPendingPayment: pendingBookings.length > 0,
                  })}
                >
                  Continue
                  <Sparkles size={18} />
                </ButtonLink>
              </div>
            </Card>

            <Card className="p-5 md:p-6">
              <Badge variant="primary">
                <CalendarClock size={14} />
                Account snapshot
              </Badge>

              <div className="mt-5 grid gap-3">
                <SnapshotRow
                  label="Email visibility"
                  value={settings?.hideEmail ?? true ? "Hidden" : "Visible"}
                />
                <SnapshotRow
                  label="Reminders"
                  value={settings?.allowReminders ?? true ? "Enabled" : "Off"}
                />
                <SnapshotRow
                  label="Reminder time"
                  value={`${settings?.defaultReminderMin ?? 30} min`}
                />
                <SnapshotRow
                  label="Budget"
                  value={formatBudget(
                    settings?.budgetMinCents,
                    settings?.budgetMaxCents,
                  )}
                />
                <SnapshotRow
                  label="Timezone"
                  value={settings?.preferredTimezone ?? "Not set"}
                />
              </div>
            </Card>
          </div>
        </div>
      </section>
    </main>
  );
}

function BellIcon() {
  return <CalendarClock size={14} />;
}

function MetricCard({
  label,
  value,
  hint,
}: {
  label: string;
  value: string;
  hint: string;
}) {
  return (
    <Card soft className="p-4">
      <p className="text-xs font-bold uppercase tracking-[0.14em] text-[var(--muted-foreground)]">
        {label}
      </p>

      <p className="mt-2 text-3xl font-black tracking-[-0.05em] text-[var(--foreground)]">
        {value}
      </p>

      <p className="mt-1 text-sm font-medium text-[var(--muted-foreground)]">
        {hint}
      </p>
    </Card>
  );
}



function ToggleCard({
  name,
  title,
  text,
  defaultChecked,
}: {
  name: string;
  title: string;
  text: string;
  defaultChecked: boolean;
}) {
  return (
    <label className="flex cursor-pointer items-start gap-4 rounded-[24px] border border-[var(--border)] bg-[var(--card-soft)] p-4 transition hover:border-[var(--border-strong)] hover:bg-[var(--background-soft)] hover:shadow-[var(--shadow-sm)]">
      <input
        name={name}
        type="checkbox"
        defaultChecked={defaultChecked}
        className="mt-1 h-5 w-5 cursor-pointer accent-[var(--primary)]"
      />

      <span>
        <span className="block font-bold tracking-[-0.02em] text-[var(--foreground)]">
          {title}
        </span>
        <span className="mt-1 block text-sm font-medium leading-6 text-[var(--muted-foreground)]">
          {text}
        </span>
      </span>
    </label>
  );
}

function SuggestionRow({ items }: { items: string[] }) {
  return (
    <div className="mt-3 flex flex-wrap gap-2">
      {items.slice(0, 6).map((item) => (
        <span
          key={item}
          className="rounded-full border border-[var(--border)] bg-[var(--card-soft)] px-3 py-1 text-xs font-bold text-[var(--muted-foreground)]"
        >
          {item}
        </span>
      ))}
    </div>
  );
}

function SnapshotRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-2xl border border-[var(--border)] bg-[var(--card-soft)] p-3">
      <p className="text-sm font-medium text-[var(--muted-foreground)]">
        {label}
      </p>

      <p className="text-right text-sm font-bold text-[var(--foreground)]">
        {value}
      </p>
    </div>
  );
}


function getNextActionTitle({
  hasLanguages,
  hasInterests,
  hasSavedHelpers,
  hasUpcoming,
  hasPendingPayment,
}: {
  hasLanguages: boolean;
  hasInterests: boolean;
  hasSavedHelpers: boolean;
  hasUpcoming: boolean;
  hasPendingPayment: boolean;
}) {
  if (hasPendingPayment) {
    return "Complete your payment.";
  }

  if (!hasLanguages || !hasInterests) {
    return "Complete your preferences.";
  }

  if (!hasSavedHelpers) {
    return "Save your first helper.";
  }

  if (!hasUpcoming) {
    return "Book a saved helper.";
  }

  return "Prepare for your next call.";
}

function getNextActionText({
  hasLanguages,
  hasInterests,
  hasSavedHelpers,
  hasUpcoming,
  hasPendingPayment,
}: {
  hasLanguages: boolean;
  hasInterests: boolean;
  hasSavedHelpers: boolean;
  hasUpcoming: boolean;
  hasPendingPayment: boolean;
}) {
  if (hasPendingPayment) {
    return "You have a reserved slot waiting for payment. Complete checkout before the reservation expires.";
  }

  if (!hasLanguages || !hasInterests) {
    return "Add languages and topics so recommendations can become more personal.";
  }

  if (!hasSavedHelpers) {
    return "Search helpers and save useful profiles so you can come back later.";
  }

  if (!hasUpcoming) {
    return "You have saved helpers. Open your saved list and book a time when you are ready.";
  }

  return "Your profile looks strong. Prepare one clear question before your next call.";
}

function getNextActionHref({
  hasLanguages,
  hasInterests,
  hasSavedHelpers,
  hasUpcoming,
  hasPendingPayment,
}: {
  hasLanguages: boolean;
  hasInterests: boolean;
  hasSavedHelpers: boolean;
  hasUpcoming: boolean;
  hasPendingPayment: boolean;
}) {
  if (hasPendingPayment) {
    return "/buyer/bookings";
  }

  if (!hasLanguages || !hasInterests) {
    return "/buyer/profile";
  }

  if (!hasSavedHelpers) {
    return "/experts";
  }

  if (!hasUpcoming) {
    return "/buyer/saved";
  }

  return "/buyer/bookings";
}

function formatBudget(min?: number | null, max?: number | null) {
  if (min && max) {
    return `€${min / 100} – €${max / 100}`;
  }

  if (min) {
    return `From €${min / 100}`;
  }

  if (max) {
    return `Up to €${max / 100}`;
  }

  return "Not set";
}

function formatProfileError(error: string) {
  if (error === "missing-name") {
    return "Please enter a display name.";
  }

  if (error === "name-too-long") {
    return "Display name is too long.";
  }

  if (error === "invalid-budget") {
    return "Please enter a valid budget range.";
  }

  if (error === "invalid-reminder") {
    return "Please choose a valid reminder time.";
  }

  if (error === "invalid-timezone") {
    return "Please enter a valid timezone.";
  }

  if (error === "not-signed-in") {
    return "Please sign in again.";
  }

  return "Something went wrong. Please try again.";
}