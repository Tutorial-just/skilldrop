export default function Page() {
  return <main className="mx-auto max-w-5xl px-6 py-12"><h1 className="text-3xl font-bold">expert/services/new</h1><p className="mt-4 text-gray-600">Coming soon.</p></main>;
}
