"use client";

import Link from "next/link";
import {
  AlertTriangle,
  Home,
  RefreshCcw,
  Search,
  ShieldCheck,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { ButtonLink } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function ErrorPage({
  error,
  reset,
}: {
  error: Error & {
    digest?: string;
  };
  reset: () => void;
}) {
  return (
    <main className="relative min-h-[calc(100vh-76px)] overflow-hidden">
      <div className="surface-grid absolute inset-0 opacity-50" />
      <div className="absolute left-[-120px] top-[-140px] h-[360px] w-[360px] rounded-full bg-[var(--danger)]/10 blur-3xl" />
      <div className="absolute bottom-[-160px] right-[-120px] h-[420px] w-[420px] rounded-full bg-[var(--primary)]/12 blur-3xl" />

      <section className="container-page relative flex min-h-[calc(100vh-76px)] items-center py-12">
        <Card className="mx-auto max-w-3xl p-6 text-center md:p-10">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-[28px] bg-[var(--danger-soft)] text-[var(--danger)] shadow-[var(--shadow-sm)]">
            <AlertTriangle size={30} />
          </div>

          <Badge variant="danger" className="mt-6">
            <AlertTriangle size={14} />
            Something went wrong
          </Badge>

          <h1 className="heading-lg mt-5 text-balance">
            SkillDrop could not load this page.
          </h1>

          <p className="mx-auto mt-4 max-w-xl text-lg leading-8 text-muted">
            This may be temporary. Try again, or return to a safe page and
            continue from there.
          </p>

          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <button type="button" onClick={reset} className="btn btn-primary">
              <RefreshCcw size={18} />
              Try again
            </button>

            <ButtonLink href="/" variant="secondary">
              <Home size={18} />
              Back home
            </ButtonLink>

            <ButtonLink href="/experts" variant="secondary">
              <Search size={18} />
              Browse experts
            </ButtonLink>
          </div>

          <div className="mt-8 rounded-[24px] border border-[var(--border)] bg-white/64 p-4 text-left">
            <div className="flex gap-3">
              <ShieldCheck
                size={18}
                className="mt-0.5 shrink-0 text-[var(--primary-dark)]"
              />

              <div>
                <p className="font-black tracking-[-0.02em]">
                  What you can do
                </p>

                <p className="mt-1 text-sm font-bold leading-6 text-muted">
                  Refresh the page, check your internet connection, or reopen the
                  page from your dashboard.
                </p>
              </div>
            </div>
          </div>

          {error.digest ? (
            <p className="mt-5 break-all rounded-2xl border border-[var(--border)] bg-white/55 p-3 text-xs font-bold text-muted">
              Error reference: {error.digest}
            </p>
          ) : null}

          <div className="mt-6 flex flex-wrap justify-center gap-3 text-sm font-bold text-muted">
            <Link href="/buyer" className="hover:text-[var(--foreground)]">
              Buyer dashboard
            </Link>

            <Link href="/expert" className="hover:text-[var(--foreground)]">
              Expert dashboard
            </Link>

            <Link href="/help" className="hover:text-[var(--foreground)]">
              Help
            </Link>
          </div>
        </Card>
      </section>
    </main>
  );
}