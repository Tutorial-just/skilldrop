import Stripe from "stripe";

const stripeSecretKey = process.env.STRIPE_SECRET_KEY;

if (!stripeSecretKey) {
  throw new Error("Missing STRIPE_SECRET_KEY environment variable.");
}

export const stripe = new Stripe(stripeSecretKey, {
  apiVersion: "2026-04-22.dahlia",
  appInfo: {
    name: "SkillDrop",
    version: "0.1.0",
    url: process.env.NEXT_PUBLIC_APP_URL,
  },
});